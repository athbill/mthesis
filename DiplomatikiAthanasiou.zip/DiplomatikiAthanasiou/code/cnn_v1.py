# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 22:08:03 2019

@author: vassi
"""

#Part 1 -  Building the CNN
from keras.models import Sequential  # for nn initialization, we can use graph
from keras.layers import Conv2D 
from keras.layers import MaxPooling2D
from keras.layers import Flatten
from keras.layers import Dense
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import TensorBoard
import time

NAME = 'lag-{}'.format(int(time.time()))
#tensorboard = TensorBoard(log_dir='logs/{}'.format(NAME))
tensorboard = TensorBoard(log_dir='logs/{}'.format(int(time.time())))

#Steop 0 - Initialize the cnn
model_v1 = Sequential()

# Step 1 - Convolution
# Feature Detectors: "16, (3, 3)" 16 filters with dimention 3x3
# input_shape=(60, 34, 3): Image dim (60x34) chanels 3
# activation = 'relu': this because we waht to ensure that we will not have negative values in feature maps
model_v1.add(Conv2D(16, (3, 3), input_shape=(60, 34, 3), activation = 'relu'))

# Step 2 - Pooling
model_v1.add(MaxPooling2D(pool_size = (2, 2)))

# Step 3 - Flattening
model_v1.add(Flatten())

# Step 4 - Full Connection
# Dimensionality of output
model_v1.add(Dense(activation = 'relu', units = 128))
model_v1.add(Dense(activation = 'sigmoid', units = 1))

# Compilig cnn
model_v1.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])

# Part2 fitting

#rescale=1./255: all pixels will get values 0-1
train_datagen = ImageDataGenerator(rescale=1./255)
#       shear_range=0.2,
#       zoom_range=0.2,
#       horizontal_flip=True)
#
test_datagen = ImageDataGenerator(rescale=1./255)

training_set = train_datagen.flow_from_directory('dataset_v1/training_set',
                                                 target_size=(60, 34),
                                                 batch_size=32,
                                                 class_mode='binary')

test_set = test_datagen.flow_from_directory('dataset_v1/test_set',
                                            target_size=(60,34),
                                            batch_size=32,
                                            class_mode='binary')

model_v1.fit_generator(training_set,
                         steps_per_epoch=160,
                         epochs=5,
                         validation_data=test_set,
                         validation_steps=40, callbacks=[tensorboard])

