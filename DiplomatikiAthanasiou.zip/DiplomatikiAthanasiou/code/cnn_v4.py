# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 22:08:03 2019

@author: vassi
"""

#Part 1 -  Building the CNN
from keras.models import Sequential  # for nn initialization, we can use graph
from keras.layers import Conv2D 
from keras.layers import MaxPooling2D, AveragePooling2D
from keras.layers import Flatten
from keras.layers import Dense, Dropout, BatchNormalization
from keras.regularizers import l1
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import TensorBoard
import time



# model_v3.save_weights('saved_models/modelw_v3.h5')
# -*- coding: utf-8 -*-
# instantiate regularizer L1
regularizer_L1 = l1(0.001)

tensorboard = TensorBoard(log_dir='logs/{}'.format(int(time.time())))

# Step 0 Initialize the cnn
model_v4 = Sequential()


model_v4.add(Conv2D(32, (3, 3), input_shape=(160, 87, 3), activation = 'relu'))
model_v4.add(MaxPooling2D(pool_size = (2, 2)))
model_v4.add(Conv2D(32, (3, 3), activation = 'relu'))
model_v4.add(MaxPooling2D(pool_size = (2, 2), strides = (2, 2)))

# Repeat steps 1 & 2 a) input_shape = from previous pool 
# activity_regularizer: works as a function of the output of the net, mainly used to regularize hidden units
model_v4.add(Conv2D(64, (3, 3), activation = 'relu'))
model_v4.add(Conv2D(64, (3, 3), activation = 'relu', activity_regularizer=regularizer_L1))
model_v4.add(MaxPooling2D(pool_size = (2, 2)))


#When adding 128+ becames the speed decreases
model_v4.add(Conv2D(128, (3, 3), activation = 'relu', padding='same'))
model_v4.add(MaxPooling2D(pool_size = (2, 2)))
model_v4.add(BatchNormalization())
#model_v4.add(Conv2D(128, (3, 3), activation = 'relu', padding='same'))
#model_v4.add(MaxPooling2D(pool_size = (2, 2)))
#model_v4.add(AveragePooling2D(pool_size = (2, 2)))




# Step 3 - Flattening
model_v4.add(Flatten())

# Step 4 - Full Connection
model_v4.add(Dense(activation = 'relu', units = 64))
model_v4.add(Dropout(0.5))
model_v4.add(Dense(activation = 'sigmoid', units = 1))


# Compilig cnn
#Params:
#   optimizer='adam': String (name of optimizer) 
#   loss=None: String (name of objective function) 
#   metrics=None, List of metrics to be evaluated by the model during training and testing
#   loss_weights=None, Optional list or dictionary specifying scalar coefficients
#   sample_weight_mode=None, If you need to do timestep-wise sample weighting (2D weights)
#   weighted_metrics=None, List of metrics to be evaluated and weighted by sample_weight or class_weight during training and testing.
#   target_tensors=None By default, Keras will create placeholders for the model's target
model_v4.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])

# Part2 fitting

train_datagen = ImageDataGenerator( rescale=1./255,
                                   rotation_range=10,
                                    shear_range=0.2,
                                    width_shift_range=0.2,
                                    height_shift_range=0.2,
                                    zoom_range=0.2,
                                    horizontal_flip=True,
                                    fill_mode='nearest')

test_datagen = ImageDataGenerator(rescale=1./255)


#'dataset_v2/training_set': data folder 
# target_size=(90, 60): same with step 1 at input_shape arg
# batch_size=32: minibatch size
# class_mode='binary': because we have 2 classes
training_set = train_datagen.flow_from_directory('/content/drive/My Drive/dataset_v3/training_set',
                                                 target_size=(160, 87),
                                                 batch_size=32,
                                                 class_mode='binary')

test_set = test_datagen.flow_from_directory('/content/drive/My Drive/dataset_v3/test_set',
                                            target_size=(160, 87),
                                            batch_size=32,
                                            class_mode='binary')
#Fit training set to the cnn
#steps_per_epoch: number of images in trainning set
#for speed reasons epoch=15, else 25+
model_v4.fit_generator(training_set,
                         steps_per_epoch=304,
                         epochs=40,
                         validation_data=test_set,
                         validation_steps=76, callbacks=[tensorboard])

#save model
model_v4.save("/content/drive/My Drive/keras_app/model_v4.h5")
# model_v3.save_weights('saved_models/modelw_v3.h5')
# -*- coding: utf-8 -*-
