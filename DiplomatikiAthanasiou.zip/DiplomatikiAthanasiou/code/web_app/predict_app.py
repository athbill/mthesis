import base64
import os
import numpy as np
import io
from PIL import Image
import keras
from keras import backend as K
from keras.models import Sequential
from keras.models import load_model
from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing.image import img_to_array
from flask import request
from flask import jsonify
from flask import Flask
import tensorflow as tf

app = Flask(__name__)

def get_model():
    global model
    model = load_model('app_models/model_v4.h5')
    model._make_predict_function()
    print(" * Model loaded!")

def preprocess_image(image, target_size):
    #if image.mode != "RGB":
        #image = image.convert("RGB")
    image = image.resize(target_size)
    image = img_to_array(image)
    image /= 255.0
    image = image.reshape(1, 120, 65, 3)
    #image = np.expand_dims(image, axis=0)

    return image

print(" * Loading Keras model...")
get_model()
global graph 
graph = tf.get_default_graph()

@app.route("/predict", methods=["POST"])
def predict():
    message = request.get_json(force=True)
    encoded = message['image']
    decoded = base64.b64decode(encoded)
    image = Image.open(io.BytesIO(decoded))
    processed_image = preprocess_image(image, target_size=(120, 65))
    
    with graph.as_default():
        prediction = model.predict(processed_image).tolist()
        prediction2 = model.predict(processed_image)
        print('1',prediction2[0])

    
    response = {
        'prediction': {
            'lagokefalos': prediction[0][0]
        }
    }
    return jsonify(response)

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 1823))
    app.run(host='127.0.0.1', port=port)
